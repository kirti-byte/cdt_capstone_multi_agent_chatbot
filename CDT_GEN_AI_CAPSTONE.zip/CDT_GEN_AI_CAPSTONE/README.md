# Multi-Agent Chatbot System

A sophisticated chatbot system leveraging multiple specialized agents to handle marketing, technical support, and generic queries. The system uses modular architecture for efficient data loading, intent recognition, and agent-based query processing.

## 🌟 Features

- **Specialized Agents**: Dedicated agents for marketing and technical support queries
- **Smart Intent Recognition**: Automatic classification of user queries
- **Data Integration**: Seamless integration with SQLite database and CSV data sources
- **Modular Architecture**: Easy to extend and customize for different use cases

## 📁 Project Structure

```
CDT_GEN_AI_CAPSTONE/
│
├── Agents/
│   ├── __init__.py
│   ├── MarketingAgent.py       # Marketing query handler
│   ├── TechnicalSupportAgent.py # Technical support handler
│
├── Data/
│   ├── Error_Codes.pdf         # Technical error reference
│   ├── marketing_data.db       # Marketing SQLite database
│   ├── telecom.csv            # Telecom marketing data
│
├── Utils/
│   ├── __init__.py
│   ├── csv_loader_sqlite.py    # CSV to SQLite loader
│   ├── intent_recognition.py   # Query intent classifier
│   
├── crew_orchestrator.py        # Main query router
├── app.bat                     # Stremlit application of crew_orchestrator.py
├── README.md                   # Documentation
├── requirements.txt            # Dependencies
```

## 🚀 Getting Started

### Prerequisites

- Python 3.8+

1. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

2. **Prepare Data**
   - Ensure `telecom.csv` is in the `Data/` folder
   - The SQLite database will be created automatically
   - Ensure Error_codes.pdf is in the `Data/` folder


3. **Add Gemini API key and update base directory path**
   - Add gemini api key in crew_orchestrator.py
   - Check and update base directory of code in crew_orchestrator.py

4. **Launch the System**
   - click on app.bat file to launch streamlit application
   - or 
   ```bash
   streamlit run crew_orchestrator.py
   ```

## 🛠 How It Works

### Intent Recognition

The system classifies queries into three categories:

- **Marketing**: Sales analysis, financial metrics, advertising performance
- **Technical Support**: Error troubleshooting, technical issues
- **Generic**: General inquiries and conversations

### Agent System

- **Marketing Agent**: Processes marketing-related queries using the SQLite database
- **Technical Support Agent**: Handles technical issues using error code documentation
- **Generic Agent**: Manages general conversation and fallback responses

### Data Management

- **CSV Loading**: Automatic processing of telecom.csv into SQLite database
- **Error Code Reference**: PDF-based lookup for technical support queries
- **Database Updates**: Automatic database creation and updates

## 📝 Usage Examples

### Marketing Queries
```python
Input: "What was our total ad spend on Google in September 2024?"
Output: "Bot Response: Marketing Data Result: Our total ad spend on Google in September 2024 was $6,356,201.41."
```

### Technical Support Queries
```python
Input: "What does error code 311 mean, and how can I fix it?"
Output: "Error code 311 indicates that the receiver is experiencing a hard drive failure. To resolve this issue, please follow these steps: Confirm that the power outlet is wired correctly.Ensure that the receiver is in a well-ventilated area.Avoid moving the receiver while it is plugged in. If the issue persists after performing these steps, you will need to replace the receiver. To prevent this error in the future, please ensure that the receiver is always in a well-ventilated area and that it is not moved while plugged in.
"
```

### Generic Queries
```python
Input: "Tell me more about this chatbot."
Output: "Generic Response: I'm sorry, I cannot assist with this query. Please ask about marketing data or technical support."
```

## 🔧 Customization

### Adding New Agents

1. Create a new agent file in `Agents/`
2. Implement the agent interface
3. Update `crew_orchestrator.py` with routing logic

```python
# Example agent implementation
class NewAgent:
    def __init__(self):
        self.name = "NewAgent"
    
    def process_query(self, query):
        # Implementation
        return response
```

### Modifying Data Sources

Update `csv_loader_sqlite.py` to handle new data sources:
Update `TechnicalAgent.py` to add different type of file fomrat as per requirement. 
Currently handling only pdf documents.

```python
def load_new_data(file_path):
    # Implementation
    pass
```

## ⚠️ Troubleshooting

### Common Issues

1. **Database Not Found**
   - Solution: Ensure `telecom.csv` is present in `Data/`
   - The database will be created automatically

2. **Missing Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Query Classification Issues**
   - Review `intent_recognition.py`
   - Adjust classification thresholds if needed