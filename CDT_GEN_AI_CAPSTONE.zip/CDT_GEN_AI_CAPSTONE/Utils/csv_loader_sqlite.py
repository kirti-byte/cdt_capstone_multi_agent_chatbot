import pandas as pd
import sqlite3
import os
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class MarketingDataLoader:
    # Define marketing columns
    marketing_columns = [
        'date', 'sales', 'sales_from_finance', 'total_ad_spend',
        'corp_Google_DISCOVERY_spend', 'corp_Google_DISPLAY_spend', 'corp_Google_PERFORMANCE_MAX_spend',
        'corp_Google_SEARCH_spend', 'corp_Google_SHOPPING_spend', 'corp_Google_VIDEO_spend',
        'corp_Horizon_VIDEO_TIER_1_spend', 'corp_Horizon_VIDEO_TIER_2_spend', 'corp_Horizon_VIDEO_TIER_3_spend',
        'corp_Horizon_VIDEO_TIER_BC_spend', 'corp_Horizon_VIDEO_TIER_HISP_spend', 'corp_Horizon_VIDEO_TIER_NA_spend',
        'corp_Horizon_VIDEO_TIER_OTT_spend', 'corp_Horizon_VIDEO_TIER_SYND_spend', 'corp_Impact_AFFILIATE_spend',
        'corp_Meta_SOCIAL_spend', 'corp_Microsoft_AUDIENCE_spend', 'corp_Microsoft_SEARCH_CONTENT_spend',
        'corp_Microsoft_SHOPPING_spend', 'local_Google_DISPLAY_spend', 'local_Google_LOCAL_spend',
        'local_Google_PERFORMANCE_MAX_spend', 'local_Google_SEARCH_spend', 'local_Google_SHOPPING_spend',
        'local_Meta_SOCIAL_spend', 'local_Simpli_fi_GEO_OPTIMIZED_DISPLAY_spend', 'local_Simpli_fi_GEO_OPTIMIZED_VIDEO_spend',
        'local_Simpli_fi_SEARCH_DISPLAY_spend', 'local_Simpli_fi_SEARCH_VIDEO_spend',
        'local_Simpli_fi_SITE_RETARGETING_DISPLAY_spend', 'local_Simpli_fi_SITE_RETARGETING_VIDEO_spend',
        'stock_market_index', 'dollar_to_pound', 'interest_rates'
    ]

    def __init__(self, csv_path: str, db_path: str, table_name: str = "marketing_data"):
        self.csv_path = csv_path
        self.db_path = db_path
        self.table_name = table_name

    def create_database_if_not_exists(self):
        """Check if the SQLite database exists. If not, create it."""
        if not os.path.exists(self.db_path):
            logging.info(f"Database '{self.db_path}' does not exist. Creating it...")
            # Connect to the database to create it
            conn = sqlite3.connect(self.db_path)
            conn.close()
            logging.info(f"Database '{self.db_path}' created successfully.")
        else:
            logging.info(f"Database '{self.db_path}' already exists.")

    def load_data_to_sqlite(self):
        """Extract data from CSV and save to SQLite database."""
        try:
            # Ensure the database exists
            self.create_database_if_not_exists()    

            # Load the CSV file into a Pandas DataFrame
            df = pd.read_csv(self.csv_path, usecols=self.marketing_columns)

            # Connect to SQLite database
            conn = sqlite3.connect(self.db_path)

            # Save the DataFrame to the SQLite table
            df.to_sql(self.table_name, conn, if_exists='replace', index=False)
            print((f"Data successfully saved to SQLite database '{self.db_path}' in table '{self.table_name}'."))
            logging.info(f"Data successfully saved to SQLite database '{self.db_path}' in table '{self.table_name}'.")

            conn.close()
        except Exception as e:
            print(f"Error loading data to SQLite: {e}")
            logging.error(f"Error loading data to SQLite: {e}")

# Main function
def main():
    csv_path = "K:/Fractal_Gen_AI_Assignments/CDT_GEN_AI_CAPSTONE/Data/telecom.csv"
    db_path = "K:/Fractal_Gen_AI_Assignments/CDT_GEN_AI_CAPSTONE/Data/marketing_data.db"
    loader = MarketingDataLoader(csv_path, db_path)
    loader.load_data_to_sqlite()

if __name__ == "__main__":
    main()
