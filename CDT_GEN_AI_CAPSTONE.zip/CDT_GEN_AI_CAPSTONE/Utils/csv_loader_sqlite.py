import pandas as pd
import sqlite3
import os
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Define marketing columns
marketing_columns = [
    'date', 'sales', 'sales_from_finance', 'total_ad_spend',
    'corp_Google_DISCOVERY_spend', 'corp_Google_DISPLAY_spend', 'corp_Google_PERFORMANCE_MAX_spend',
    'corp_Google_SEARCH_spend', 'corp_Google_SHOPPING_spend', 'corp_Google_VIDEO_spend',
    'corp_Horizon_VIDEO_TIER_1_spend', 'corp_Horizon_VIDEO_TIER_2_spend', 'corp_Horizon_VIDEO_TIER_3_spend',
    'corp_Horizon_VIDEO_TIER_BC_spend', 'corp_Horizon_VIDEO_TIER_HISP_spend', 'corp_Horizon_VIDEO_TIER_NA_spend',
    'corp_Horizon_VIDEO_TIER_OTT_spend', 'corp_Horizon_VIDEO_TIER_SYND_spend', 'corp_Impact_AFFILIATE_spend',
    'corp_Meta_SOCIAL_spend', 'corp_Microsoft_AUDIENCE_spend', 'corp_Microsoft_SEARCH_CONTENT_spend',
    'corp_Microsoft_SHOPPING_spend', 'local_Google_DISPLAY_spend', 'local_Google_LOCAL_spend',
    'local_Google_PERFORMANCE_MAX_spend', 'local_Google_SEARCH_spend', 'local_Google_SHOPPING_spend',
    'local_Meta_SOCIAL_spend', 'local_Simpli_fi_GEO_OPTIMIZED_DISPLAY_spend', 'local_Simpli_fi_GEO_OPTIMIZED_VIDEO_spend',
    'local_Simpli_fi_SEARCH_DISPLAY_spend', 'local_Simpli_fi_SEARCH_VIDEO_spend',
    'local_Simpli_fi_SITE_RETARGETING_DISPLAY_spend', 'local_Simpli_fi_SITE_RETARGETING_VIDEO_spend',
    'stock_market_index', 'dollar_to_pound', 'interest_rates'
]

# Extract data from CSV and save to SQLite
def load_data_to_sqlite(csv_path: str, db_path: str, table_name: str = "marketing_data"):
    try:
        # Load the CSV file into a Pandas DataFrame
        df = pd.read_csv(csv_path, usecols=marketing_columns)

        # Connect to SQLite database (or create it if it doesn't exist)
        conn = sqlite3.connect(db_path)

        # Save the DataFrame to the SQLite table
        df.to_sql(table_name, conn, if_exists='replace', index=False)
        logging.info(f"Data successfully saved to SQLite database '{db_path}' in table '{table_name}'.")
        
        conn.close()
    except Exception as e:
        logging.error(f"Error loading data to SQLite: {e}")

# Main function
def main():
    csv_path = "K:/Fractal_Gen_AI_Assignments/CDT_GEN_AI_CAPSTONE/Data/telecom.csv"
    db_path = "marketing_data.db"
    load_data_to_sqlite(csv_path, db_path)

if __name__ == "__main__":
    main()
