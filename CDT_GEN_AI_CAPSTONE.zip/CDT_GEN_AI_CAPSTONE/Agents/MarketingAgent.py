import pandas as pd
import sqlite3
import logging
import google.generativeai as genai

# Configure AI
genai.configure(api_key='AIzaSyA02seKHtFxxVmaJ56HJUwRjBfa9h6Xz_s')
model = genai.GenerativeModel("gemini-1.5-flash")

# Configure logging
logging.basicConfig(level=logging.ERROR, format='%(asctime)s - %(levelname)s - %(message)s')

def generate_sql_query(user_query: str) -> str:
    """Generate SQL query based on user input."""
    system_prompt = """
     You are a SQL query assistant. Your job is to:
    1. Understand user input in natural language.
    2. Generate an accurate SQL query based on the input and the given database schema.
    3. Your response should only consist of SQL Query and no other keywords accepted by SQL query.

        **Context:**
        The dataset is stored in a SQLite database with the table name `marketing_data`. 
        The table includes the following columns:
        marketing_columns = [
            'date', 'sales', 'sales_from_finance', 'total_ad_spend',
            'corp_Google_DISCOVERY_spend', 'corp_Google_DISPLAY_spend', 'corp_Google_PERFORMANCE_MAX_spend',
            'corp_Google_SEARCH_spend', 'corp_Google_SHOPPING_spend', 'corp_Google_VIDEO_spend',
            'corp_Horizon_VIDEO_TIER_1_spend', 'corp_Horizon_VIDEO_TIER_2_spend', 'corp_Horizon_VIDEO_TIER_3_spend',
            'corp_Horizon_VIDEO_TIER_BC_spend', 'corp_Horizon_VIDEO_TIER_HISP_spend', 'corp_Horizon_VIDEO_TIER_NA_spend',
            'corp_Horizon_VIDEO_TIER_OTT_spend', 'corp_Horizon_VIDEO_TIER_SYND_spend', 'corp_Impact_AFFILIATE_spend',
            'corp_Meta_SOCIAL_spend', 'corp_Microsoft_AUDIENCE_spend', 'corp_Microsoft_SEARCH_CONTENT_spend',
            'corp_Microsoft_SHOPPING_spend', 'local_Google_DISPLAY_spend', 'local_Google_LOCAL_spend',
            'local_Google_PERFORMANCE_MAX_spend', 'local_Google_SEARCH_spend', 'local_Google_SHOPPING_spend',
            'local_Meta_SOCIAL_spend', 'local_Simpli_fi_GEO_OPTIMIZED_DISPLAY_spend', 'local_Simpli_fi_GEO_OPTIMIZED_VIDEO_spend',
            'local_Simpli_fi_SEARCH_DISPLAY_spend', 'local_Simpli_fi_SEARCH_VIDEO_spend',
            'local_Simpli_fi_SITE_RETARGETING_DISPLAY_spend', 'local_Simpli_fi_SITE_RETARGETING_VIDEO_spend',
            'stock_market_index', 'dollar_to_pound', 'interest_rates'
        ]

        **Instructions:**
        1. Analyze the user's query and generate an accurate SQL query to retrieve the requested data.
        2. Ensure SQL queries are optimized for performance, taking into account conditions like date ranges, aggregation (e.g., sum, average), filtering, and grouping as specified.
        3. Include appropriate error-handling instructions for missing or invalid data.

        **Examples:**
        1. **User Query:** "What is the total sales for 2024?"
        - **SQL Query:** `SELECT SUM(sales) AS total_sales FROM marketing_data WHERE date BETWEEN '2024-01-01' AND '2024-12-31';`
        
        2. **User Query:** "List total ad spend for Google channels in the last quarter."
        - **SQL Query:** `SELECT date, SUM(total_ad_spend) AS total_google_ad_spend FROM marketing_data WHERE date >= '2024-10-01' GROUP BY date;`
        
        3. **User Query:** "What was the average interest rate in 2023?"
        - **SQL Query:** `SELECT AVG(interest_rates) AS avg_interest_rate FROM marketing_data WHERE date BETWEEN '2023-01-01' AND '2023-12-31';`

        **Output Requirements:**
        - Return the SQL query.
        - Your query response should only contain SQL query which should be executable in the database.
    """
    input_prompt = system_prompt + "\n\nUser Query:\n" + user_query

    try:
        response = model.generate_content(input_prompt)
        if response and response.text:
            return response.text.strip()
        else:
            logging.error("No response from the model.")
            return ""
    except Exception as e:
        logging.error(f"Error generating SQL query: {e}")
        return ""

def clean_sql_query(sql_query: str) -> str:
    """Remove Markdown-style formatting from the SQL query."""
    return sql_query.replace("```sql", "").replace("```", "").strip()


def execute_sql_query(sql_query: str, db_path: str):
    """Execute the SQL query against the SQLite database and return the result as tuples."""
    try:
        with sqlite3.connect(db_path) as conn:
            logging.info(f"Executing query:\n{sql_query}")
            result = pd.read_sql_query(sql_query, conn)
            return result.to_records(index=False)  # Convert DataFrame to structured array (tuple-like)
    except Exception as e:
        logging.error(f"Error executing SQL query: {e}")
        return None


def generate_natural_language_response(query: str, result_tuples) -> str:
    """Generate a natural language response based on the query and result tuples."""
    try:
        # Convert result tuples to a string format for the LLM
        result_text = '\n'.join([str(row) for row in result_tuples])

        # Prepare the prompt
        prompt = (
            f"The user asked: '{query}'. "
            f"Here are the results derived from the database query:\n{result_text}\n\n"
            "Please generate a natural language response that clearly and accurately answers the user's question based on this data. "
            "Ensure the response is concise, clear, and fully addresses the user's query."
        )
            # concise, 
        response = model.generate_content(prompt)
        if response and response.text:
            return response.text.strip()
        else:
            return "Unable to generate a natural language response at this time."
    except Exception as e:
        logging.error(f"Error generating natural language response: {e}")
        return "Error generating natural language response."

if __name__ == "__main__":
    user_query = "total sales of year 2024?"
    sql_query = generate_sql_query(user_query)
    clean_query = clean_sql_query(sql_query)  # Clean up the query
    print(f"Generated SQL Query:\n{clean_query}")

    if clean_query:
        result = execute_sql_query(clean_query, db_path="marketing_data.db")
        if result is not None:
            response = generate_natural_language_response(user_query, result)
            print("Response to the User:")
            print(response)
        else:
            print("No data available for the query.")
