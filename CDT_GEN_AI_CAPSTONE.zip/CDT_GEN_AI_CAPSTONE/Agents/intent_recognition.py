from langchain.prompts import PromptTemplate
import google.generativeai as genai

class IntentRecognizer:
    """
    A class to recognize the intent of a user's query using Gemini LLM.

    Attributes:
        api_key (str): API key for accessing the Gemini LLM.
        llm (object): Instance of the configured Gemini Generative Model.
    """

    def __init__(self, api_key):
        """
        Initializes the IntentRecognizer with the provided API key and sets up the LLM model.

        Args:
            api_key (str): API key required to configure the Gemini LLM.
        """
        genai.configure(api_key=api_key)  # Configure Gemini LLM with the provided API key.
        self.llm = genai.GenerativeModel("gemini-1.5-flash")  # Load the specific Gemini model.

    def recognize_intent(self, query: str) -> str:
        """
        Recognizes the intent of the user's query by classifying it into predefined categories.

        Args:
            query (str): The user query for which the intent needs to be recognized.

        Returns:
            str: The recognized intent, which can be one of:
                 - "Marketing Data": If the query involves sales, advertising, or financial metrics.
                 - "Technical Support": If the query involves error codes, issues, troubleshooting, or technical resolutions.
                 - "Generic": If the query does not fit into the above categories.
        """
        # Define the prompt template for classifying the user query.
        prompt = PromptTemplate(
            input_variables=["query"],
            template="""
            Classify the user's query into one or more of the following intents:
            - "Marketing Data" if the query involves sales, advertising, or financial metrics.
            - "Technical Support" if the query involves error codes, troubleshooting, or technical resolutions.
            - "Generic" if the query does not belong to the above categories.
            
            ### Examples - 

            Marketing Data Queries:  
            - What was the total ad spend on Google for [Month, Year]?
            - How did the dollar-to-pound exchange rate impact sales in Q2 [Year]?
            - What was the total sales for the quarter ending [Quarter, Year]?

            Technical Support Queries:  
            - What are the potential causes of error code 311?
            - How can internet buffering issues on a Hopper be resolved?
            - What steps should be taken if a Hopper is stuck on the Android recovery screen?
            - How can internet speed and buffering issues on a Hopper be addressed?

            Generic Queries:  
            - What are the company’s customer service hours?
            - How do I upgrade my subscription plan?
            - What is the refund policy for canceled subscriptions?
            - hi or other greetings.

            Classify the user query to the appropriate agent.

            Query: {query}
            Intent:
            """
        )

        try:
            # Use the LLM to generate a response based on the input query and the defined prompt.
            response = self.llm.generate_content([prompt.format(query=query)])
            # Extract the classified intent from the LLM response.
            response = response.candidates[0].content.parts[0].text.split(":")[1].strip()
            return response
        except Exception as e:
            # Log and handle any errors that occur during intent recognition.
            print(f"Error in intent recognition: {e}")
            return "Generic"  # Return a default intent in case of an error.

if __name__ == '__main__':
    # Example usage of the IntentRecognizer class.
    recognizer = IntentRecognizer(api_key="AIzaSyA02seKHtFxxVmaJ56HJUwRjBfa9h6Xz_s")
    # Classify a sample query to determine its intent.
    output = recognizer.recognize_intent(query="what is the total sales of 2025?")
    
    # The intent classification result will be stored in `output`.
    print(f"Recognized Intent: {output}")


