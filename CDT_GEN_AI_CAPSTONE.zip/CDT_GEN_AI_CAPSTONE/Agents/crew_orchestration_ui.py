import streamlit as st
from intent_recognition import IntentRecognizer
import importlib

# Import functions from marketingdataagent.py
marketing_agent = importlib.import_module("MarketingAgent")

# Import functions from technicalsupportagent.py
technical_agent = importlib.import_module("TechnicalSupportAgent")
pdf_path = "K:/Fractal_Gen_AI_Assignments/CDT_GEN_AI_CAPSTONE/Data/Error_Codes.pdf"

# Define GenericResponseAgent and CrewOrchestrator
class GenericResponseAgent:
    def process_query(self, query: str):
        return "I'm sorry, I cannot assist with this query. Please ask about marketing data or technical support."

class CrewOrchestrator:
    def __init__(self, intent_recognizer, api_key):
        self.intent_recognizer = intent_recognizer
        self.generic_agent = GenericResponseAgent()
        self.api_key = api_key  # Store API key for LLM usage

    def process_user_query(self, query: str):
        # Recognize intent
        intent = self.intent_recognizer.recognize_intent(query).strip().lower()
        st.info(f"Recognized Intent: {intent}")
        print("intent is here ",intent)
        responses = []

        try:
            # Handle Marketing Data Intent
            if "marketing data" in intent:
                try:
                    # Step 1: Generate and clean SQL query
                    sql_query = marketing_agent.generate_sql_query(query)
                    clean_query = marketing_agent.clean_sql_query(sql_query)
                    if clean_query:
                        
                        # Step 2: Execute the SQL query and fetch results
                        result = marketing_agent.execute_sql_query(clean_query,db_path="marketing_data.db")
                        if result is not None:
                            # Convert DataFrame to tabular format
                            response = marketing_agent.generate_natural_language_response(user_query, result)
                            responses.append(f"Marketing Data Result:\n{response}")
                        else:
                            responses.append("The requested data could not be found in the database.")
                except Exception:
                     responses.append("The query could not be generated due to unclear intent. Please provide more details.")

            # Handle Technical Support Intent
            elif "technical support" in intent:
                try:
                    pipeline = technical_agent.RAGPipeline(pdf_path, api_key)
                    documents = pipeline.load_and_split_documents()
                    pipeline.create_document_embeddings()
                    response = pipeline.generate_answer(query)
                    
                    if response:
                        responses.append(f"Technical Support Response: {response}")
                    else:
                        responses.append("The requested information is not available.")

                except Exception as e:
                    responses.append(f"Technical Support: Unable to retrieve the information due to an issue: {str(e)}")

            # Handle Generic Response Intent
            elif "generic" in intent:
                response = self.generic_agent.process_query(query = query)
                responses.append(f"Generic Response: {response}")

            # If no recognized intent
            if not responses:
                responses.append("I'm sorry, I could not process your query. Please make sure your question is clear.")

        except Exception as e:
            responses.append(f"An unexpected error occurred: {str(e)}. Please try again later.")

        # Combine all responses and return in natural language
        return "\n\n".join(responses)

# Initialize Streamlit UI
st.title("Multiagent Chatbot")
st.write("Ask about **Marketing Data** or **Technical Support**.")

# Session state to store conversation history
if "conversation" not in st.session_state:
    st.session_state.conversation = []

if "user_query" not in st.session_state:
    st.session_state.user_query = ""

# Initialize Intent Recognizer and Crew Orchestrator
api_key = "AIzaSyA02seKHtFxxVmaJ56HJUwRjBfa9h6Xz_s"  # Replace with your LLM API key
intent_recognizer = IntentRecognizer(api_key)
orchestrator = CrewOrchestrator(intent_recognizer, api_key)

# User query input
user_query = st.text_input("Your Query", value=st.session_state.user_query, key="user_query_input")

# Process query on button click
highlighted_response = None  # To keep track of the latest response
if st.button("Send"):
    if user_query.strip():
        # Get the response from CrewOrchestrator
        response = orchestrator.process_user_query(user_query)

        # Add user query and response to conversation history
        st.session_state.conversation.append({"user": user_query, "bot": response})

        # Store the latest response for highlighting
        highlighted_response = {"user": user_query, "bot": response}

        # Clear the input box for the next query
        st.session_state.user_query = ""

# Display conversation history in reverse chronological order
if st.session_state.conversation:
    st.markdown("### Conversations:")
    if highlighted_response:
        # Highlight the most recent exchange
        st.markdown("#### **Latest Query and Response:**")
        st.markdown(f"**You:** {highlighted_response['user']}")
        st.markdown(f"**Bot Response:** :green[{highlighted_response['bot']}]")
        st.markdown("---")

    # Show remaining history
    for exchange in reversed(st.session_state.conversation[:-1] if highlighted_response else st.session_state.conversation):
        st.write(f"**You:** {exchange['user']}")
        st.write(f"**Response:** {exchange['bot']}")
        st.markdown("---")
