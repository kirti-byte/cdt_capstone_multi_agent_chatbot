import streamlit as st
from crewai import Crew, Agent, Task, Process
from Utils.intent_recognition import IntentRecognizer
from Utils.csv_loader_sqlite import MarketingDataLoader
import importlib
import os

# Configuration and paths
api_key = "AIzaSyA02seKHtFxxVmaJ56HJUwRjBfa9h6Xz_s"
base_dir = "K:/Fractal_Gen_AI_Assignments"

pdf_path = os.path.join(base_dir, "CDT_GEN_AI_CAPSTONE/Data/Error_Codes.pdf")
telecom_data_path = os.path.join(base_dir, "CDT_GEN_AI_CAPSTONE/Data/telecom.csv")
marketing_db_path = os.path.join(base_dir, "CDT_GEN_AI_CAPSTONE/Data/marketing_data.db")

table_name = "marketing_data"

# Import agent modules
marketing_agent_module = importlib.import_module("Agents.MarketingAgent")
technical_agent_module = importlib.import_module("Agents.TechnicalSupportAgent")

class MarketingAgent(Agent):
    def __init__(self):
        super().__init__(
            name="Marketing Data Agent",
            role="marketing_analyst",
            goal="Process marketing data queries using SQL and provide insights",
            backstory="I am an expert in analyzing marketing data and providing insights using SQL queries.",
            allow_delegation=False,
            verbose=True,
            tools=[]  # Added empty tools list
        )
        
    def execute_task(self, task: str) -> str:  # Updated type hints
        try:
            # Since task is now a string, use it directly
            sql_query = marketing_agent_module.generate_sql_query(task)
            clean_query = marketing_agent_module.clean_sql_query(sql_query)
            if clean_query:
                result = marketing_agent_module.execute_sql_query(clean_query, marketing_db_path)
                if result is not None:
                    response = marketing_agent_module.generate_natural_language_response(task, result)
                    return f"Marketing Data Result:\n{response}"
            return "The requested data could not be found in the database."
        except Exception as e:
            return f"Error processing marketing query: {str(e)}"

class TechnicalSupportAgent(Agent):
    def __init__(self):
        super().__init__(
            name="Technical Support Agent",
            role="technical_support",
            goal="Provide technical support using RAG pipeline",
            backstory="I am a technical support specialist who helps resolve issues using documentation.",
            allow_delegation=False,
            verbose=True,
            tools=[]  # Added empty tools list
        )
        
    def execute_task(self, task: str) -> str:  # Updated type hints
        try:
            # Since task is now a string, use it directly
            pipeline = technical_agent_module.RAGPipeline(pdf_path, api_key)
            documents = pipeline.load_and_split_documents()
            pipeline.create_document_embeddings()
            response = pipeline.generate_answer(task)
            return f"Technical Support Response: {response}" if response else "The requested information is not available."
        except Exception as e:
            return f"Technical Support: Unable to retrieve the information due to an issue: {str(e)}"

class GenericAgent(Agent):
    def __init__(self):
        super().__init__(
            name="Generic Response Agent",
            role="general_assistant",
            goal="Handle general queries and provide fallback responses",
            backstory="I provide general assistance when queries don't match specific domains.",
            allow_delegation=False,
            verbose=True,
            tools=[]  # Added empty tools list
        )
        
    def execute_task(self, task: str) -> str:  # Updated type hints
        return "I'm sorry, I cannot assist with this query. Please ask about marketing data or technical support."

class CrewAIOrchestrator:
    def __init__(self, intent_recognizer, api_key):
        self.intent_recognizer = intent_recognizer
        self.api_key = api_key
        self.marketing_agent = MarketingAgent()
        self.technical_agent = TechnicalSupportAgent()
        self.generic_agent = GenericAgent()
        
    def create_task(self, query: str, intent: str) -> Task:
        return Task(
            description=query,  # Simplified task description
            expected_output="A natural language response to the user's query",
            agent=self._get_agent_for_intent(intent)
        )
    
    def _get_agent_for_intent(self, intent: str) -> Agent:
        if "marketing data" in intent:
            return self.marketing_agent
        elif "technical support" in intent:
            return self.technical_agent
        return self.generic_agent
    
    def process_user_query(self, query: str) -> str:
        intent = self.intent_recognizer.recognize_intent(query).strip().lower()
        st.info(f"Recognized Intent: {intent}")
        
        try:
            task = self.create_task(query, intent)
            agent = self._get_agent_for_intent(intent)
            
            # Execute the task directly with the agent
            result = agent.execute_task(query)
            return result if result else "No response generated."
            
        except Exception as e:
            st.error(f"Error during task execution: {str(e)}")
            return f"An unexpected error occurred: {str(e)}. Please try again later."

# Streamlit UI code
def main():
    st.title("Multiagent Chatbot")
    st.write("Ask about **Telecom Marketing Data** or **Technical Support**.")

    # Initialize session state
    if "conversation" not in st.session_state:
        st.session_state.conversation = []

    if "user_query" not in st.session_state:
        st.session_state.user_query = ""

    # Initialize components
    try:
        csv_loader_sqlite = MarketingDataLoader(telecom_data_path, marketing_db_path, table_name)
        csv_loader_sqlite.load_data_to_sqlite()
        intent_recognizer = IntentRecognizer(api_key)
        orchestrator = CrewAIOrchestrator(intent_recognizer, api_key)

        # User interface
        user_query = st.text_input("Your Query", value=st.session_state.user_query, key="user_query_input")

        # Process query
        highlighted_response = None
        if st.button("Send"):
            if user_query.strip():
                with st.spinner("Processing your query..."):
                    response = orchestrator.process_user_query(user_query)
                    st.session_state.conversation.append({"user": user_query, "bot": response})
                    highlighted_response = {"user": user_query, "bot": response}
                    st.session_state.user_query = ""

        # Display conversation history
        if st.session_state.conversation:
            st.markdown("### Conversations:")
            if highlighted_response:
                st.markdown("#### **Latest Query and Response:**")
                st.markdown(f"**You:** {highlighted_response['user']}")
                st.markdown(f"**Bot Response:** :green[{highlighted_response['bot']}]")
                st.markdown("---")

            for exchange in reversed(st.session_state.conversation[:-1] if highlighted_response else st.session_state.conversation):
                st.write(f"**You:** {exchange['user']}")
                st.write(f"**Response:** {exchange['bot']}")
                st.markdown("---")

    except Exception as e:
        st.error(f"Application Error: {str(e)}")

if __name__ == "__main__":
    main()