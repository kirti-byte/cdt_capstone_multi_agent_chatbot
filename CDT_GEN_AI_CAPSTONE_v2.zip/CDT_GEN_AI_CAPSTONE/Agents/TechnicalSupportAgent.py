from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
import google.generativeai as genai
from sklearn.metrics.pairwise import cosine_similarity
import pandas as pd
import numpy as np
import faiss  # Import FAISS library

class RAGPipeline:
    """
    A class to create a Retrieval-Augmented Generation (RAG) pipeline.
    Handles document loading, splitting, embedding generation, 
    vector search using FAISS, and response generation.
    """

    def __init__(self, pdf_path, gemini_api_key):
        """
        Initializes the pipeline with necessary configurations.

        Args:
        pdf_path (str): Path to the PDF file to be processed.
        gemini_api_key (str): API key for Google Gemini.
        """
        self.pdf_path = pdf_path
        self.gemini_api_key = gemini_api_key
        self.documents = None  # Placeholder for documents
        self.embeddings = None  # Placeholder for document embeddings
        self.index = None  # FAISS index

        # Configure Gemini API
        try:
            genai.configure(api_key=self.gemini_api_key)
        except Exception as e:
            raise RuntimeError("Failed to configure Gemini API. Check your API key.") from e

    def load_and_split_documents(self):
        """
        Loads and splits the PDF documents into smaller chunks.
        """
        try:
            loader = PyPDFLoader(self.pdf_path)
            pages = loader.load_and_split()
            text = "\n".join([doc.page_content for doc in pages])

            text_splitter = RecursiveCharacterTextSplitter(
                chunk_size=1500,
                chunk_overlap=750,
                length_function=len,
                # is_separator_regex=False,
                separators=["\n","\n\n", "  ", ""]

            )
            docs = text_splitter.create_documents([text])
            for i, doc in enumerate(docs):
                doc.metadata = {"doc_id": i}

            self.documents = docs
            return docs
        except FileNotFoundError:
            raise FileNotFoundError(f"PDF file not found at {self.pdf_path}.")
        except Exception as e:
            raise RuntimeError("Error loading or splitting documents.") from e

    def get_embeddings(self, text):
        """
        Generates embeddings for a given text using Gemini.

        Args:
        text (str): The input text to generate embeddings for.

        Returns:
        list: A list of embeddings.
        """
        try:
            model = 'models/embedding-001'
            embedding = genai.embed_content(
                model=model,
                content=text,
                task_type="retrieval_document"
            )
            return embedding['embedding']
        except Exception as e:
            raise RuntimeError("Error generating embeddings.") from e

    def create_document_embeddings(self):
        """
        Creates document embeddings and builds a FAISS index.
        """
        try:
            # Generate embeddings for each document
            content_list = [doc.page_content for doc in self.documents]
            self.embeddings = np.array([self.get_embeddings(content) for content in content_list])

            # Build a FAISS index
            dimension = len(self.embeddings[0])  # Dimensionality of embeddings
            self.index = faiss.IndexFlatL2(dimension)  # L2 (Euclidean) similarity
            self.index.add(self.embeddings)
        except Exception as e:
            raise RuntimeError("Error creating document embeddings.") from e

    def get_relevant_docs(self, query, top_k=3):
        """
        Retrieves the most relevant documents for a query using FAISS.

        Args:
        query (str): The query for which relevant documents are retrieved.
        top_k (int): Number of top relevant documents to retrieve.

        Returns:
        list: A list of relevant document content.
        """
        try:
            query_embedding = np.array([self.get_embeddings(query)])
            distances, indices = self.index.search(query_embedding, top_k)

            relevant_docs = [self.documents[i].page_content for i in indices[0]]
            return relevant_docs
        except Exception as e:
            raise RuntimeError("Error retrieving relevant documents.") from e

    @staticmethod
    def make_rag_prompt(query, relevant_passage):
        """
        Creates a RAG-style prompt for query-answering.

        Args:
        query (str): The user query.
        relevant_passage (list): List of relevant passages.

        Returns:
        str: A prompt for the language model.
        """
        relevant_passage = ' '.join(relevant_passage)
        prompt = f"""
            You are a technical support assistant specializing in diagnosing and resolving issues with satellite TV receivers and related equipment. 
            You have access to a comprehensive database containing details about error codes, their meanings, causes, and resolutions, along with troubleshooting steps for various issues. 
            Use the information to provide clears, actionable, and step-by-step solutions for user queries.

            Guidelines:
            1. Identify the key issue or error code in the query.
            2. Reference the relevant information from your database to provide detailed solutions.
            3. If the query involves multiple error codes or issues, prioritize troubleshooting steps logically.
            4. If the query is indirect or general, infer the relevant issue and provide the most accurate advice.
            5. Always aim to include preventive tips or follow-up actions where applicable.

            Example Queries:
            1. "What are the potential causes and solutions for error code 015D?"
            2. "How can intermittent signal loss on a Hopper 3 be diagnosed and resolved?"
            3. "What is the meaning of error code 311, and how can it be fixed?"
            4. "What are common issues with Wireless Joeys, and how can they be resolved?"
            5. "What steps should be taken if a Hopper is stuck on the Android recovery screen?"
            6. "How should a technician prioritize troubleshooting multiple error codes (e.g., 015, 021, 311)?"
            7. "What are the potential causes of frequent Hopper 3 reboots, and how can they be resolved?"
            8. "What are some preventive maintenance tips for DISH equipment?"
            9. "How can internet speed and buffering issues on a Hopper be addressed?"

            share relevant response of the user query.

            Always ensure your response is concise, user-friendly, and tailored to resolve the user's query effectively.

            f"QUESTION: '{query}'\n"
            f"PASSAGE: '{relevant_passage}'\n\n"
            f"ANSWER:"
        """
        return prompt

    def generate_response(self, user_prompt):
        """
        Generates a response using Gemini LLM.

        Args:
        user_prompt (str): The prompt for the language model.

        Returns:
        str: The generated response.
        """
        try:
            model = genai.GenerativeModel('gemini-pro')
            answer = model.generate_content(user_prompt)
            return answer.text
        except Exception as e:
            raise RuntimeError("Error generating response.") from e

    def generate_answer(self, query):
        """
        Generates an answer for the given query using the RAG pipeline.

        Args:
        query (str): The user query.

        Returns:
        str: The generated answer.
        """
        try:
            relevant_text = self.get_relevant_docs(query)
            prompt = self.make_rag_prompt(query, relevant_passage=relevant_text)
            answer = self.generate_response(prompt)
            return answer
        except Exception as e:
            raise RuntimeError("Error generating answer.") from e


# Usage Example
if __name__ == "__main__":
    pdf_path = "K:/Fractal_Gen_AI_Assignments/CDT_GEN_AI_CAPSTONE/Data/Error_Codes.pdf"
    gemini_api_key = "AIzaSyA02seKHtFxxVmaJ56HJUwRjBfa9h6Xz_s"

    try:
        pipeline = RAGPipeline(pdf_path, gemini_api_key)
        pipeline.load_and_split_documents()
        pipeline.create_document_embeddings()
        query = "How can internet speed and buffering issues on a Hopper be addressed?"
        answer = pipeline.generate_answer(query)
        print("Answer:", answer)
    except Exception as e:
        print(f"An error occurred: {e}")
